import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:soilpedialk/pages/navPages/camTest.dart';
import 'package:soilpedialk/pages/navPages/mainPage.dart';
import 'package:soilpedialk/pages/welcomePage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Flutter",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MainPage(),
    );
  }
}
